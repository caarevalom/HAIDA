
  # Professional HTML Presentation

  This is a code bundle for Professional HTML Presentation. The original project is available at https://www.figma.com/design/RsLHtCESIfN92DLfDSEQRE/Professional-HTML-Presentation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  