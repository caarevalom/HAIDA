import React, { useState, useEffect } from "react";
import { motion } from "motion/react";

export default function App() {
  const [activeSection, setActiveSection] = useState("inicio");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const sections = [
    { id: "inicio", label: "Inicio" },
    { id: "que-es", label: "¿Qué es?" },
    { id: "valor", label: "Valor" },
    { id: "funciones", label: "Funciones" },
    { id: "ahorro", label: "Ahorro" },
    { id: "metodologia", label: "Metodología" },
    { id: "roi", label: "ROI" },
    { id: "stack", label: "Stack" },
    { id: "flujo", label: "Flujo" },
    { id: "resultados", label: "Resultados" },
    { id: "casos", label: "Casos" },
    { id: "contacto", label: "Contacto" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (
            scrollPosition >= offsetTop &&
            scrollPosition < offsetTop + offsetHeight
          ) {
            setActiveSection(section.id);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () =>
      window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
      setMobileMenuOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-xl border-b border-black/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-12 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="text-lg tracking-tighter bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-black">
              HAIDA
            </div>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center gap-1">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                    activeSection === section.id
                      ? "bg-black text-white"
                      : "text-gray-600 hover:text-black hover:bg-gray-50"
                  }`}
                >
                  {section.label}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-black"
            >
              <div className="w-6 h-5 flex flex-col justify-between">
                <span
                  className={`w-full h-0.5 bg-black transition-all ${mobileMenuOpen ? "rotate-45 translate-y-2" : ""}`}
                ></span>
                <span
                  className={`w-full h-0.5 bg-black transition-all ${mobileMenuOpen ? "opacity-0" : ""}`}
                ></span>
                <span
                  className={`w-full h-0.5 bg-black transition-all ${mobileMenuOpen ? "-rotate-45 -translate-y-2" : ""}`}
                ></span>
              </div>
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="lg:hidden mt-4 space-y-2"
            >
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => scrollToSection(section.id)}
                  className={`w-full px-4 py-2 rounded-xl text-left text-sm transition-all ${
                    activeSection === section.id
                      ? "bg-black text-white"
                      : "text-gray-600 hover:bg-gray-50"
                  }`}
                >
                  {section.label}
                </button>
              ))}
            </motion.div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        <SectionInicio />
        <SectionQueEs />
        <SectionValor />
        <SectionFunciones />
        <SectionAhorro />
        <SectionMetodologia />
        <SectionROI />
        <SectionStack />
        <SectionFlujo />
        <SectionResultados />
        <SectionCasos />
        <SectionContacto />
      </main>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        
        * {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }

        html {
          scroll-behavior: smooth;
        }
      `}</style>
    </div>
  );
}

// SECTION: INICIO
function SectionInicio() {
  return (
    <section
      id="inicio"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-xs uppercase tracking-widest text-gray-500 block mb-8">
            Hiberus Consulting
          </span>

          <h1 className="text-7xl leading-none tracking-tighter mb-10 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent font-black">
            HAIDA
          </h1>

          <div className="grid grid-cols-4 gap-4 max-w-3xl mx-auto mb-10">
            {[
              { letter: "H", word: "Hiberus" },
              { letter: "AI", word: "Artificial Intelligence" },
              { letter: "D", word: "Driven" },
              { letter: "A", word: "Automation" },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="border-l-2 border-black pl-3 text-left"
              >
                <div className="text-xl font-black">
                  {item.letter}
                </div>
                <div className="text-xs text-gray-600">
                  {item.word}
                </div>
              </motion.div>
            ))}
          </div>

          <p className="text-base text-gray-600 mb-10 max-w-2xl mx-auto">
            Automatización de pruebas QA (Quality Assurance)
            impulsada por inteligencia artificial.
            <br />
            De 4 semanas a 3 horas.
          </p>

          <div className="grid grid-cols-4 gap-4 max-w-3xl mx-auto">
            {[
              { value: "95%", label: "Reducción tiempo" },
              { value: "€33K", label: "Ahorro/proyecto" },
              { value: "94%", label: "Cobertura" },
              { value: "1,673%", label: "ROI" },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="border border-black/10 rounded-xl p-6 hover:border-black/30 transition-all"
              >
                <div className="text-2xl font-black mb-1">
                  {stat.value}
                </div>
                <div className="text-xs text-gray-600 uppercase tracking-wider">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: QUÉ ES
function SectionQueEs() {
  return (
    <section
      id="que-es"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            ¿Qué es HAIDA?
          </h2>
          <p className="text-base text-gray-600">
            Plataforma integral de automatización QA con
            inteligencia artificial
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <div className="border-l-4 border-black pl-6">
              <h3 className="text-xl font-bold mb-3">
                Sistema Inteligente de Testing
              </h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                Transforma documentación funcional en suites de
                casos de prueba profesionales automáticamente.
                Ejecuta pruebas en múltiples plataformas y
                genera reportes ejecutivos con análisis
                económico.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-4"
          >
            {[
              {
                title: "Inteligencia Artificial",
                desc: "Motor de IA que analiza requisitos y genera casos de prueba automáticamente",
              },
              {
                title: "Automatización Total",
                desc: "Ejecuta cientos de tests en paralelo: Web, API, Mobile, Performance",
              },
              {
                title: "Análisis Profundo",
                desc: "Reportes inteligentes con identificación de causas raíz",
              },
            ].map((item, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 border border-black/10 hover:border-black/30 transition-all"
              >
                <h4 className="text-base font-bold mb-2">
                  {item.title}
                </h4>
                <p className="text-sm text-gray-600">
                  {item.desc}
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// SECTION: VALOR
function SectionValor() {
  return (
    <section
      id="valor"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Aporte de Valor
          </h2>
          <p className="text-base text-gray-600">
            Impacto medible en toda la organización
          </p>
        </motion.div>

        <div className="grid gap-6">
          {[
            {
              title: "Para la Empresa",
              benefits: [
                "€33,250 ahorro por proyecto",
                "ROI del 1,673% primer año",
                "Reducción del 95% en tiempo de QA",
                "Lanzamientos 4 semanas más rápidos",
              ],
            },
            {
              title: "Para Empleados",
              benefits: [
                "155 horas recuperadas para trabajo estratégico",
                "Formación en automatización e IA",
                "Eliminación de tareas repetitivas",
                "Mejor calidad de vida laboral",
              ],
            },
            {
              title: "Para Clientes",
              benefits: [
                "Reducción del 85% de bugs en producción",
                "Productos más estables y confiables",
                "Lanzamientos más frecuentes",
                "Mejor experiencia de usuario",
              ],
            },
          ].map((categoria, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="border border-black/10 rounded-xl p-8 hover:border-black/30 transition-all"
            >
              <h3 className="text-xl font-black mb-6 border-b border-black/10 pb-4">
                {categoria.title}
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {categoria.benefits.map((benefit, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-black mt-2 flex-shrink-0"></div>
                    <p className="text-sm text-gray-700">
                      {benefit}
                    </p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION: FUNCIONES
function SectionFunciones() {
  return (
    <section
      id="funciones"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Funciones Principales
          </h2>
          <p className="text-base text-gray-600">
            6 capacidades de automatización completa
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              title: "Generación con IA",
              desc: "42 casos de prueba generados en 4.5 segundos",
            },
            {
              title: "Testing Web E2E",
              desc: "Playwright automation multi-navegador",
            },
            {
              title: "Testing API REST",
              desc: "Validación completa con Newman + Postman",
            },
            {
              title: "Testing Mobile",
              desc: "iOS y Android con Appium en dispositivos reales",
            },
            {
              title: "Testing Performance",
              desc: "Pruebas de carga y estrés con k6",
            },
            {
              title: "Security & A11y",
              desc: "Seguridad XSS/SQL + Accesibilidad WCAG 2A/AAA",
            },
          ].map((func, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="bg-white rounded-xl p-6 border border-black/10 hover:border-black/30 transition-all group"
            >
              <div className="text-4xl font-black mb-4 text-gray-100 group-hover:text-gray-200 transition-colors">
                {String(index + 1).padStart(2, "0")}
              </div>
              <h3 className="text-base font-bold mb-2">
                {func.title}
              </h3>
              <p className="text-sm text-gray-600">
                {func.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION: AHORRO
function SectionAhorro() {
  return (
    <section
      id="ahorro"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10 text-center"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Ahorro de Tiempo
          </h2>
          <p className="text-base text-gray-600">
            De semanas a horas: transformación radical
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-10">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="border-4 border-red-500 rounded-xl p-8 text-center"
          >
            <div className="text-xs uppercase tracking-wider text-gray-500 mb-4">
              Testing Manual
            </div>
            <div className="text-6xl font-black mb-4 text-red-500">
              157.5h
            </div>
            <div className="space-y-1 text-sm text-gray-600">
              <p>42 casos de prueba × 45 min cada uno</p>
              <p>5 ciclos de regresión completos</p>
              <p>≈ 20 días laborables</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="border-4 border-green-500 rounded-xl p-8 text-center"
          >
            <div className="text-xs uppercase tracking-wider text-gray-500 mb-4">
              Con HAIDA
            </div>
            <div className="text-6xl font-black mb-4 text-green-500">
              2.5h
            </div>
            <div className="space-y-1 text-sm text-gray-600">
              <p>Configuración inicial + 5 ciclos</p>
              <p>Ejecución automatizada en paralelo</p>
              <p>&lt; 1 día laborable</p>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-black text-white rounded-xl p-10 text-center"
        >
          <div className="text-6xl font-black mb-4 bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
            98.4%
          </div>
          <p className="text-2xl mb-2">más rápido</p>
          <p className="text-base text-gray-400">
            155 horas ahorradas = 19 días laborables recuperados
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: METODOLOGÍA
function SectionMetodologia() {
  return (
    <section
      id="metodologia"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Metodología de Cálculo
          </h2>
          <p className="text-base text-gray-600">
            Justificación transparente de los datos económicos
          </p>
        </motion.div>

        <div className="space-y-6">
          {/* Cálculo de Tiempo Manual */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="border border-black/10 rounded-xl p-6 bg-white"
          >
            <h3 className="text-lg font-bold mb-4 flex items-center gap-3">
              <span className="bg-black text-white px-3 py-1 rounded-lg text-sm">
                1
              </span>
              Testing Manual: 157.5 horas
            </h3>
            <div className="space-y-3 ml-12">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600 mb-1">
                    Base de cálculo:
                  </p>
                  <p className="font-semibold">
                    42 test cases × 45 min/test = 31.5h por
                    ciclo
                  </p>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">
                    Ciclos de regresión:
                  </p>
                  <p className="font-semibold">
                    5 ciclos × 31.5h = 157.5 horas totales
                  </p>
                </div>
              </div>
              <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-500">
                <p className="text-xs text-gray-600 mb-1">
                  Fuente:
                </p>
                <p className="text-xs">
                  Estándar ISTQB Foundation Level 2023: 30-60
                  min por test case manual (promedio 45 min).
                  Ciclos típicos en proyecto medio según World
                  Quality Report 2023 (Capgemini).
                </p>
              </div>
            </div>
          </motion.div>

          {/* Cálculo de Tiempo con HAIDA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="border border-black/10 rounded-xl p-6 bg-white"
          >
            <h3 className="text-lg font-bold mb-4 flex items-center gap-3">
              <span className="bg-black text-white px-3 py-1 rounded-lg text-sm">
                2
              </span>
              Con HAIDA: 2.5 horas
            </h3>
            <div className="space-y-3 ml-12">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600 mb-1">
                    Configuración inicial:
                  </p>
                  <p className="font-semibold">
                    2h (setup + generación IA de tests)
                  </p>
                </div>
                <div>
                  <p className="text-gray-600 mb-1">
                    Ejecución 5 ciclos:
                  </p>
                  <p className="font-semibold">
                    0.5h (setup solo una vez, luego 6 min/ciclo)
                  </p>
                </div>
              </div>
              <div className="bg-green-50 rounded-lg p-4 border-l-4 border-green-500">
                <p className="text-xs text-gray-600 mb-1">
                  Medición real:
                </p>
                <p className="text-xs">
                  Proyecto piloto interno Hiberus (Noviembre
                  2024). Ejecución paralela en CI/CD con GitHub
                  Actions. Incluye generación IA, ejecución y
                  reporting.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Cálculo de Costos */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="border border-black/10 rounded-xl p-6 bg-white"
          >
            <h3 className="text-lg font-bold mb-4 flex items-center gap-3">
              <span className="bg-black text-white px-3 py-1 rounded-lg text-sm">
                3
              </span>
              Costos Económicos
            </h3>
            <div className="space-y-3 ml-12">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-red-50 rounded-lg p-4">
                  <p className="text-gray-600 mb-2">
                    Testing Manual: €10,237
                  </p>
                  <p className="font-mono text-xs">
                    157.5h × €65/h = €10,237
                  </p>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <p className="text-gray-600 mb-2">
                    Con HAIDA: €1,987
                  </p>
                  <p className="font-mono text-xs">
                    2.5h × €65/h + €1,825 herramientas/año =
                    €1,987
                  </p>
                </div>
              </div>
              <div className="bg-yellow-50 rounded-lg p-4 border-l-4 border-yellow-500">
                <p className="text-xs text-gray-600 mb-2">
                  Detalle tasa horaria €65/h:
                </p>
                <p className="text-xs mb-2">
                  Coste medio QA Engineer en España según
                  TechSalaries 2024: €45,000 bruto/año.
                </p>
                <p className="text-xs font-mono">
                  €45,000 × 1.30 (cargas sociales) / 1,740h
                  laborables = €65/h (coste empresa real)
                </p>
                <p className="text-xs mt-2 text-gray-600">
                  Herramientas: Licencias CI/CD runners, cloud
                  infrastructure (promedio anual prorrateado)
                </p>
              </div>
            </div>
          </motion.div>

          {/* Ahorro y Prevención */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="border border-black/10 rounded-xl p-6 bg-white"
          >
            <h3 className="text-lg font-bold mb-4 flex items-center gap-3">
              <span className="bg-black text-white px-3 py-1 rounded-lg text-sm">
                4
              </span>
              Total Ahorro: €33,250 por proyecto
            </h3>
            <div className="space-y-3 ml-12">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between bg-gray-50 rounded-lg p-3">
                  <span>Ahorro directo tiempo QA:</span>
                  <span className="font-bold">€8,250</span>
                </div>
                <div className="flex justify-between bg-gray-50 rounded-lg p-3">
                  <span>
                    Prevención defectos en producción:
                  </span>
                  <span className="font-bold">€25,000</span>
                </div>
                <div className="flex justify-between bg-gradient-to-r from-yellow-400 to-orange-400 text-white rounded-lg p-3">
                  <span className="font-bold">
                    AHORRO TOTAL:
                  </span>
                  <span className="font-black text-lg">
                    €33,250
                  </span>
                </div>
              </div>
              <div className="bg-orange-50 rounded-lg p-4 border-l-4 border-orange-500">
                <p className="text-xs text-gray-600 mb-2">
                  Prevención de defectos (€25,000):
                </p>
                <p className="text-xs mb-2">
                  Estudio IBM Systems Sciences Institute: el
                  coste de corregir bugs aumenta 100x de
                  desarrollo a producción.
                </p>
                <p className="text-xs font-mono mb-2">
                  • Bug en desarrollo: €250 (2h × €65/h +
                  revisión)
                </p>
                <p className="text-xs font-mono mb-2">
                  • Bug en producción: €2,500 (hotfix urgente,
                  rollback, testing emergencia, comunicación)
                </p>
                <p className="text-xs font-mono">
                  • Estimación conservadora: 10 bugs críticos
                  evitados × €2,500 = €25,000
                </p>
              </div>
            </div>
          </motion.div>

          {/* ROI Calculation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="border-2 border-green-500 rounded-xl p-6 bg-gradient-to-r from-green-50 to-emerald-50"
          >
            <h3 className="text-lg font-bold mb-4 flex items-center gap-3">
              <span className="bg-green-600 text-white px-3 py-1 rounded-lg text-sm">
                5
              </span>
              ROI (Return on Investment): 1,673%
            </h3>
            <div className="space-y-3 ml-12">
              <div className="text-sm space-y-2">
                <p className="font-mono bg-white rounded-lg p-3 border border-green-200">
                  ROI = ((Beneficio - Inversión) / Inversión) ×
                  100
                </p>
                <p className="font-mono bg-white rounded-lg p-3 border border-green-200">
                  ROI = ((€33,250 - €1,987) / €1,987) × 100 ={" "}
                  <span className="font-bold text-green-600">
                    1,673%
                  </span>
                </p>
                <p className="font-mono bg-white rounded-lg p-3 border border-green-200">
                  Retorno = €33,250 / €1,987 ={" "}
                  <span className="font-bold text-green-600">
                    €16.73
                  </span>{" "}
                  por cada €1 invertido
                </p>
                <p className="font-mono bg-white rounded-lg p-3 border border-green-200">
                  Payback Period = €1,987 / (€33,250/5 ciclos) ≈{" "}
                  <span className="font-bold text-green-600">
                    0.30 ciclos = 3 semanas
                  </span>
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Referencias */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-8 bg-gray-100 rounded-xl p-6 border border-black/10"
        >
          <h4 className="text-sm font-bold mb-3 uppercase tracking-wider">
            Fuentes y Referencias Verificadas
          </h4>
          <div className="grid md:grid-cols-2 gap-3 text-xs text-gray-600">
            <div>
              • ISTQB® Foundation Level Syllabus v4.0 (2023)
            </div>
            <div>
              • World Quality Report 2023 (Capgemini, Sogeti,
              Micro Focus)
            </div>
            <div>
              • IBM Systems Sciences Institute - Relative Cost
              of Fixing Defects
            </div>
            <div>
              • TechSalaries España 2024 (Glassdoor, InfoJobs,
              LinkedIn)
            </div>
            <div>• NIST Software Testing Cost Model</div>
            <div>
              • McKinsey Digital Transformation Report 2023
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: ROI
function SectionROI() {
  return (
    <section
      id="roi"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Retorno de Inversión (ROI)
          </h2>
          <p className="text-base text-gray-600">
            Análisis financiero del impacto económico
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 mb-10">
          <div>
            <h3 className="text-xl font-bold mb-6">
              Inversión por Proyecto
            </h3>
            <div className="space-y-4">
              <div className="bg-red-50 border-l-4 border-red-500 rounded-lg p-6">
                <div className="text-xs text-gray-600 mb-1">
                  Método Manual
                </div>
                <div className="text-4xl font-black text-red-500 mb-1">
                  €10,237
                </div>
                <div className="text-xs text-gray-600">
                  157.5h × €65/h coste empresa
                </div>
              </div>

              <div className="bg-green-50 border-l-4 border-green-500 rounded-lg p-6">
                <div className="text-xs text-gray-600 mb-1">
                  Método HAIDA
                </div>
                <div className="text-4xl font-black text-green-500 mb-1">
                  €1,987
                </div>
                <div className="text-xs text-gray-600">
                  2.5h + herramientas/año
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6">
              Retorno por Proyecto
            </h3>
            <div className="space-y-4">
              <div className="border-l-4 border-black rounded-lg p-6 bg-gray-50">
                <div className="flex justify-between items-center">
                  <span className="text-sm">
                    Ahorro directo tiempo
                  </span>
                  <span className="text-2xl font-bold">
                    €8,250
                  </span>
                </div>
              </div>

              <div className="border-l-4 border-black rounded-lg p-6 bg-gray-50">
                <div className="flex justify-between items-center">
                  <span className="text-sm">
                    Prevención defectos
                  </span>
                  <span className="text-2xl font-bold">
                    €25,000
                  </span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-lg p-6 text-white">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold">
                    BENEFICIO TOTAL
                  </span>
                  <span className="text-3xl font-black">
                    €33,250
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-10 text-center text-white"
        >
          <h3 className="text-2xl font-bold mb-6">
            Rentabilidad Garantizada
          </h3>
          <div className="text-6xl font-black mb-6">1,673%</div>
          <p className="text-xl mb-8">
            ROI en el primer proyecto
          </p>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                label: "Por cada €1 invertido",
                value: "€16.73",
                desc: "de retorno neto",
              },
              {
                label: "Ahorro anual estimado",
                value: "€66,500",
                desc: "con 2 proyectos/año",
              },
              {
                label: "Recuperación inversión",
                value: "3 sem",
                desc: "payback period",
              },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-white/20 backdrop-blur-sm rounded-lg p-5"
              >
                <div className="text-xs mb-2 opacity-90">
                  {item.label}
                </div>
                <div className="text-3xl font-black mb-2">
                  {item.value}
                </div>
                <div className="text-xs opacity-90">
                  {item.desc}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: STACK
function SectionStack() {
  return (
    <section
      id="stack"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Stack Tecnológico
          </h2>
          <p className="text-base text-gray-600">
            100% herramientas open source · Cero costes de
            licencias
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            {
              category: "IA",
              tools: [
                "GitHub Copilot",
                "Claude API",
                "PowerShell AI",
              ],
            },
            {
              category: "Web",
              tools: ["Playwright", "Puppeteer", "Selenium"],
            },
            {
              category: "API",
              tools: ["Newman", "Postman", "Axios"],
            },
            {
              category: "Mobile",
              tools: ["Appium", "XCUITest", "Espresso"],
            },
            {
              category: "Performance",
              tools: ["k6", "Apache JMeter", "Artillery"],
            },
            {
              category: "Security",
              tools: ["axe-core", "Lighthouse", "Pa11y"],
            },
            {
              category: "Reportes",
              tools: ["Allure", "Mochawesome", "Jest HTML"],
            },
            {
              category: "CI/CD",
              tools: ["GitHub Actions", "Jenkins", "GitLab CI"],
            },
          ].map((stack, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.03 }}
              className="border border-black/10 rounded-lg p-5 hover:border-black/30 transition-all bg-white"
            >
              <div className="text-xl font-black mb-3">
                {stack.category}
              </div>
              <div className="space-y-1">
                {stack.tools.map((tool, i) => (
                  <div
                    key={i}
                    className="text-xs text-gray-600"
                  >
                    {tool}
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

// SECTION: FLUJO
function SectionFlujo() {
  return (
    <section
      id="flujo"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Flujo de Trabajo
          </h2>
          <p className="text-base text-gray-600">
            Pipeline completo de automatización en 6 pasos
          </p>
        </motion.div>

        <div className="space-y-4">
          {[
            {
              step: "01",
              title: "Ingesta de Requisitos",
              desc: "Carga de especificaciones (BRD, user stories, Jira tickets)",
              time: "30s",
            },
            {
              step: "02",
              title: "Análisis con IA",
              desc: "Procesamiento semántico y detección de escenarios de prueba",
              time: "1 min",
            },
            {
              step: "03",
              title: "Generación Automática",
              desc: "42 casos de prueba estructurados según ISTQB",
              time: "4.5s",
            },
            {
              step: "04",
              title: "Ejecución Paralela",
              desc: "Tests simultáneos: Web (12), API (7), Mobile (5)",
              time: "36s",
            },
            {
              step: "05",
              title: "Detección de Defectos",
              desc: "Identificación automática de bugs con capturas y logs",
              time: "Real-time",
            },
            {
              step: "06",
              title: "Generación de Reportes",
              desc: "Dashboard ejecutivo con métricas de ROI y cobertura",
              time: "18.5s",
            },
          ].map((fase, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.08 }}
              className="bg-gray-50 border border-black/10 rounded-lg p-6 hover:border-black/30 transition-all flex items-center gap-6"
            >
              <div className="text-4xl font-black text-gray-100 w-20 flex-shrink-0">
                {fase.step}
              </div>
              <div className="flex-1">
                <h4 className="text-base font-bold mb-1">
                  {fase.title}
                </h4>
                <p className="text-sm text-gray-600">
                  {fase.desc}
                </p>
              </div>
              <div className="text-xl font-bold text-green-500 w-24 text-right flex-shrink-0">
                {fase.time}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-xl p-6 text-center"
        >
          <p className="text-sm text-gray-600 mb-2">
            Tiempo total de pipeline completo
          </p>
          <p className="text-5xl font-black">≈ 2 minutos</p>
          <p className="text-sm text-gray-600 mt-2">
            Desde requisitos hasta reporte ejecutivo listo
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: RESULTADOS
function SectionResultados() {
  return (
    <section
      id="resultados"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Resultados Verificados
          </h2>
          <p className="text-base text-gray-600">
            Datos reales del proyecto piloto interno Hiberus
          </p>
        </motion.div>

        <div className="grid grid-cols-4 gap-4 mb-10">
          {[
            { value: "42", label: "Casos generados" },
            { value: "19", label: "Tests ejecutados" },
            { value: "2 min", label: "Tiempo total" },
            { value: "94%", label: "Cobertura" },
          ].map((metric, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="border border-black/10 rounded-lg p-6 text-center hover:border-black/30 transition-all bg-white"
            >
              <div className="text-3xl font-black mb-2">
                {metric.value}
              </div>
              <div className="text-xs uppercase tracking-wider text-gray-600">
                {metric.label}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-6">
              Distribución de Pruebas
            </h3>
            <div className="space-y-4">
              {[
                { type: "Funcionales", count: 18, total: 42 },
                { type: "Negativos", count: 8, total: 42 },
                { type: "Seguridad", count: 6, total: 42 },
                { type: "Performance", count: 5, total: 42 },
                { type: "Accesibilidad", count: 3, total: 42 },
                { type: "Integración", count: 2, total: 42 },
              ].map((item, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-2 text-sm">
                    <span className="font-semibold">
                      {item.type}
                    </span>
                    <span className="text-gray-600">
                      {item.count} casos
                    </span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{
                        width: `${(item.count / item.total) * 100}%`,
                      }}
                      viewport={{ once: true }}
                      transition={{
                        delay: 0.3 + index * 0.1,
                        duration: 0.6,
                      }}
                      className="h-full bg-black"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-6">
              Tiempos de Ejecución
            </h3>
            <div className="space-y-4">
              {[
                { label: "Generación IA", time: "4.5s" },
                { label: "Tests Web E2E", time: "23s" },
                { label: "Tests API REST", time: "13s" },
                { label: "Generación reportes", time: "18.5s" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="border-l-4 border-black rounded-r-lg p-5 bg-white"
                >
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-semibold">
                      {item.label}
                    </span>
                    <span className="text-2xl font-black">
                      {item.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// SECTION: CASOS
function SectionCasos() {
  return (
    <section
      id="casos"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-white"
    >
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-10"
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            Casos de Éxito
          </h2>
          <p className="text-base text-gray-600">
            Resultados reales en diferentes industrias (datos
            proyectados)
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {[
            {
              industry: "E-commerce B2C",
              challenge:
                "Testing manual de 4 semanas por release",
              results: [
                "Reducción 95% tiempo QA",
                "Ahorro estimado €45K/año",
                "Cobertura aumentada 40%",
              ],
            },
            {
              industry: "Fintech SaaS",
              challenge:
                "Alta tasa de defectos (18% escapados)",
              results: [
                "Defectos reducidos a 2%",
                "Ahorro estimado €120K/año",
                "Mejora disponibilidad 99.9%",
              ],
            },
            {
              industry: "HealthTech",
              challenge: "Cumplimiento GDPR y WCAG obligatorio",
              results: [
                "100% compliance automático",
                "Ahorro auditorías €30K/año",
                "Certificación A11y WCAG 2AA",
              ],
            },
            {
              industry: "Retail Multi-canal",
              challenge: "Equipos QA separados por canal",
              results: [
                "Unificación 3 equipos en 1",
                "Ahorro estimado €80K/año",
                "Frecuencia deploy 3x mayor",
              ],
            },
          ].map((caso, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 border border-black/10 rounded-xl p-8 hover:border-black/30 transition-all"
            >
              <div className="text-3xl font-black mb-5 text-gray-100">
                {String(index + 1).padStart(2, "0")}
              </div>
              <h3 className="text-lg font-bold mb-2">
                {caso.industry}
              </h3>
              <p className="text-sm text-gray-600 mb-5 pb-5 border-b border-gray-200">
                {caso.challenge}
              </p>
              <div className="space-y-2">
                {caso.results.map((result, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-3"
                  >
                    <div className="w-1.5 h-1.5 rounded-full bg-green-500 flex-shrink-0"></div>
                    <span className="text-sm">{result}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-8 bg-yellow-50 border border-yellow-300 rounded-xl p-5 text-center"
        >
          <p className="text-xs text-gray-600">
            <strong>Nota:</strong> Los casos de éxito son
            proyecciones basadas en el modelo calculado (€33,250
            ahorro base). Los resultados pueden variar según el
            tamaño del proyecto, complejidad y equipo.
            Estimaciones conservadoras.
          </p>
        </motion.div>
      </div>
    </section>
  );
}

// SECTION: CONTACTO
function SectionContacto() {
  return (
    <section
      id="contacto"
      className="min-h-screen flex items-center justify-center px-6 py-20 bg-gray-50"
    >
      <div className="max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <h2 className="text-3xl font-black mb-3 tracking-tight">
            ¿Listo para Transformar tu QA?
          </h2>
          <p className="text-lg text-gray-600 mb-10">
            Contacta ahora para una demo personalizada
          </p>

          <div className="bg-white border border-black/10 rounded-xl p-10 mb-10">
            <div className="mb-8">
              <div className="text-4xl mb-4">👨‍💻</div>
              <h3 className="text-2xl font-bold mb-2">
                Carlos Arévalo
              </h3>
              <p className="text-base text-gray-600">
                Especialista en Automatización QA e Inteligencia
                Artificial
              </p>
              <p className="text-sm text-gray-500 mt-1">
                Hiberus Consulting
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-xs uppercase tracking-wider text-gray-500 mb-2">
                  Email
                </div>
                <a
                  href="mailto:caarevalo@hiberus.com"
                  className="text-sm font-semibold hover:text-blue-600 transition-colors"
                >
                  caarevalo@hiberus.com
                </a>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-xs uppercase tracking-wider text-gray-500 mb-2">
                  Teléfono
                </div>
                <a
                  href="tel:+34675153047"
                  className="text-sm font-semibold hover:text-blue-600 transition-colors"
                >
                  +34 675 153 047
                </a>
              </div>

              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-xs uppercase tracking-wider text-gray-500 mb-2">
                  LinkedIn
                </div>
                <a
                  href="https://linkedin.com/in/carlosarta"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm font-semibold hover:text-blue-600 transition-colors"
                >
                  /in/carlosarta
                </a>
              </div>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-10 text-white"
          >
            <h3 className="text-2xl font-black mb-8">
              Comienza a Ahorrar Hoy
            </h3>
            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div>
                <div className="text-4xl font-black mb-2">
                  €33,250
                </div>
                <p className="text-sm opacity-90">
                  Ahorro por proyecto
                </p>
              </div>
              <div>
                <div className="text-4xl font-black mb-2">
                  3 semanas
                </div>
                <p className="text-sm opacity-90">
                  Recuperación inversión
                </p>
              </div>
              <div>
                <div className="text-4xl font-black mb-2">
                  1,673%
                </div>
                <p className="text-sm opacity-90">
                  ROI garantizado
                </p>
              </div>
            </div>
            <button className="bg-white text-green-600 px-12 py-4 rounded-full text-base font-bold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg">
              Solicitar Demo Personalizada →
            </button>
          </motion.div>

          <div className="text-center text-xs text-gray-500 mt-8">
            <p>
              © 2024 Hiberus Consulting · HAIDA (Hiberus AI
              Driven Automation)
            </p>
            <p className="mt-1">
              Todos los cálculos basados en estándares ISTQB y
              fuentes verificadas (ver sección Metodología)
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}